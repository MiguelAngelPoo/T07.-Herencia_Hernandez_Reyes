﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital
{
    public class Persona
    {
        //encapsular
        public string Nombre { get; set; }
        public string FechaNa { get; set; }
        public string NumeroTe { get; set; }
        public string Email { get; set; }




    }
}
